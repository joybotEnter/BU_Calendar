import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { EventService } from 'src/app/services/event.service';

// ✅ Ionic imports (THIS is what was missing)
import {
  IonContent,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonButtons,
  IonButton,
  IonIcon,
  IonFab,
  IonFabButton
} from '@ionic/angular/standalone';

@Component({
  selector: 'app-events',
  standalone: true,
  templateUrl: './events.page.html',
  styleUrls: ['./events.page.scss'],
  imports: [
    CommonModule,

    // ✅ REQUIRED IONIC MODULES
    IonContent,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonButtons,
    IonButton,
    IonIcon,
    IonFab,
    IonFabButton
  ]
})
export class EventsPage {

  private router = inject(Router);
  private eventService = inject(EventService);

  events: any[] = [];
  private sub?: Subscription;

  // 🔥 Ionic lifecycle
  ionViewWillEnter() {
    this.loadEvents();
  }

  // 🔥 FIREBASE LOAD
  loadEvents() {
    this.sub?.unsubscribe();

    this.sub = this.eventService.getEvents().subscribe((data: any[]) => {
      this.events = data || [];
    });
  }

  // 🔙 back to home
  goBack() {
    this.router.navigateByUrl('/home');
  }

  // ➕ add event
  goToAddEvent() {
    this.router.navigateByUrl('/add-event');
  }

  // ✏️ edit event
  edit(id: string) {
    this.router.navigateByUrl(`/edit-event/${id}`);
  }

  // 🎨 department colors
  getColor(dept: string = ''): string {
    switch (dept.toUpperCase()) {
      case 'CITE': return '#8b5cf6';
      case 'CNAHS': return '#3b82f6';
      case 'CLAGE': return '#ec4899';
      case 'CEDE': return '#f97316';
      case 'CHMT': return '#ef4444';
      case 'CBAA': return '#facc15';
      case 'CEHD': return '#22c55e';
      default: return '#006633';
    }
  }

  // 🧹 cleanup
  ngOnDestroy() {
    this.sub?.unsubscribe();
  }
}