import { Component, NgZone, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import {
  AlertController
} from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';
import {
  informationCircleOutline,
  logOutOutline,
  chevronBackOutline,
  closeOutline
} from 'ionicons/icons';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonMenu,
  IonMenuButton,
  IonMenuToggle,
  IonButtons,
  IonList,
  IonItem,
  IonLabel,
  IonIcon,
  IonCard,
  IonCardContent,
  IonRow,
  IonCol,
  IonButton,
  IonModal
} from '@ionic/angular/standalone';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonMenu,
    IonMenuButton,
    IonMenuToggle,
    IonButtons,
    IonList,
    IonItem,
    IonLabel,
    IonIcon,
    IonCard,
    IonCardContent,
    IonRow,
    IonCol,
    IonButton,
    IonModal,
  ]
})
export class HomePage {

  today = new Date();

  logoutConfirmOpen = false;
  aboutOpen = false;

  totalEvents = 12;
  upcomingEvents = 5;

  selectedDepartment: string | null = null;

  departments = [
    { code: 'CITE', name: 'IT Education', icon: '💻' },
    { code: 'CNAHS', name: 'Nursing & Health', icon: '🩺' },
    { code: 'CLAGE', name: 'Arts & GenEd', icon: '📚' },
    { code: 'CEDE', name: 'Education', icon: '🎓' },
    { code: 'CHMT', name: 'Hospitality', icon: '🍽️' },
    { code: 'CBAA', name: 'Business', icon: '💼' },
    { code: 'CEHD', name: 'Engineering', icon: '⚙️' }
  ];

  constructor(
    private router: Router,
    private authService: AuthService,
    private alertController: AlertController,
    private ngZone: NgZone,
    private cdr: ChangeDetectorRef
  ) {
    addIcons({
      informationCircleOutline,
      logOutOutline,
      chevronBackOutline,
      closeOutline
    });
  }

  // ======================
  // Navigation
  // ======================

  goTo(page: string) {
    this.router.navigateByUrl('/' + page);
  }

  selectDepartment(code: string) {
    this.selectedDepartment = code;
  }

  // ======================
  // About Modal
  // ======================

  goAbout() {
    this.aboutOpen = true;
  }

  closeAbout() {
    this.aboutOpen = false;
  }

  // ======================
  // Logout Modal
  // ======================

  async confirmLogout() {
    const alert = await this.alertController.create({
      header: 'Logout',
      message: 'Are you sure you want to log out?',
      backdropDismiss: false,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Logout',
          role: 'destructive',
          handler: () => {
            this.doLogout();
          }
        }
      ]
    });

    await alert.present();
  }

  cancelLogout() {
    this.logoutConfirmOpen = false;
  }

  async doLogout() {
    this.logoutConfirmOpen = false;

    try {
      await this.authService.logout();

      localStorage.clear();
      sessionStorage.clear();

      await this.router.navigateByUrl('/login', {
        replaceUrl: true
      });

    } catch (error) {
      console.error('Logout failed:', error);
    }
  }

  // ======================
  // Department Colors
  // ======================

  getColor(code: string): string {
    switch (code) {
      case 'CITE':
        return '#8b5cf6';
      case 'CNAHS':
        return '#3b82f6';
      case 'CLAGE':
        return '#ec4899';
      case 'CEDE':
        return '#f97316';
      case 'CHMT':
        return '#ef4444';
      case 'CBAA':
        return '#facc15';
      case 'CEHD':
        return '#22c55e';
      default:
        return '#999999';
    }
  }

  getDepartmentCount(code: string): number {
    return Math.floor(Math.random() * 10) + 1;
  }
}