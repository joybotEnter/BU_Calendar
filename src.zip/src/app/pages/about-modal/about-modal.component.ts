import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalController } from '@ionic/angular/standalone';

import { addIcons } from 'ionicons';
import { chevronBackOutline, closeOutline } from 'ionicons/icons';

import { IonButton, IonIcon } from '@ionic/angular/standalone';

@Component({
  selector: 'app-about-modal',
  standalone: true,
  imports: [CommonModule, IonButton, IonIcon],
  template: `
    <div class="modal-card">

      <div class="modal-topbar">
        <button class="modal-back-btn" (click)="close()">
          <ion-icon name="chevron-back-outline"></ion-icon>
        </button>

        <span class="modal-topbar-title">About the University</span>

        <button class="modal-close-btn" (click)="close()">
          <ion-icon name="close-outline"></ion-icon>
        </button>
      </div>

      <div class="about-hero">
        <img src="assets/bu-logo.png" class="about-logo" alt="BU Logo">
      </div>

      <div class="modal-body">

        <div class="about-brand">
          <h2>Baliuag University</h2>
          <p>Student Calendar Portal</p>
        </div>

        <div class="about-section">
          <div class="about-label">Mission</div>
          <p>
            Baliuag University is committed to providing accessible,
            quality education that develops competent, ethical,
            and service-oriented individuals.
          </p>
        </div>

        <div class="about-section">
          <div class="about-label">Vision</div>
          <p>
            To become a leading institution recognized for academic
            excellence, innovation, and community engagement.
          </p>
        </div>

        <div class="about-section">
          <div class="about-label">Core Values</div>
          <div class="values-grid">
            <div class="value-chip">Integrity</div>
            <div class="value-chip">Excellence</div>
            <div class="value-chip">Service</div>
            <div class="value-chip">Community</div>
          </div>
        </div>

        <ion-button expand="block" color="success" (click)="close()">
          Close
        </ion-button>

      </div>

    </div>
  `,
  styleUrls: ['./about-modal.component.scss']
})
export class AboutModalComponent {

  constructor(private modalCtrl: ModalController) {
    addIcons({ chevronBackOutline, closeOutline });
  }

  close() {
    this.modalCtrl.dismiss();
  }
}