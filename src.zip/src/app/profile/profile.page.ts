import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardContent,
  IonButton,
  ToastController
} from '@ionic/angular/standalone';

import { Router } from '@angular/router';

import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonCard,
    IonCardContent,
    IonButton
  ]
})
export class ProfilePage implements OnInit {

  user: any = {};

  constructor(
    private auth: AuthService,
    private router: Router,
    private toast: ToastController
  ) {}

  ngOnInit() {

    const currentUser = this.auth.getCurrentUser();

    if (!currentUser) return;

    this.auth.getUserProfile(currentUser.uid)
      .subscribe(data => {

        this.user = data;

      });

  }

  async logout() {

    await this.auth.logout();

    const toast = await this.toast.create({

      message: 'Logged out successfully.',

      duration: 1500,

      color: 'success'

    });

    await toast.present();

    this.router.navigateByUrl('/login', {
      replaceUrl: true
    });

  }

}