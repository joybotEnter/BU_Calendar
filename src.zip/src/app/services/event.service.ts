import { Injectable, inject } from '@angular/core';
import { doc, docData } from '@angular/fire/firestore';
import {
  Firestore,
  collection,
  addDoc,
  collectionData,

  getDoc,
  updateDoc
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class EventService {

  private firestore = inject(Firestore);
  private eventsRef = collection(this.firestore, 'events');

  // 🔥 GET ALL EVENTS (REALTIME)
  getEvents(): Observable<any[]> {
    return collectionData(this.eventsRef, { idField: 'id' }) as Observable<any[]>;
  }

  // ➕ ADD EVENT
  addEvent(event: any) {
    return addDoc(this.eventsRef, event);
  }

  // 🔍 GET ONE EVENT
  getEvent(id: string) {
  const ref = doc(this.firestore, `events/${id}`);
  return docData(ref, { idField: 'id' });
}


  // ✏️ UPDATE EVENT
  updateEvent(id: string, data: any) {
    const ref = doc(this.firestore, `events/${id}`);
    return updateDoc(ref, data);
  }
}